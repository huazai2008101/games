import { defineConfig } from 'vite'
import { resolve } from 'path'

export default defineConfig({
  build: {
    lib: {
      entry: resolve(__dirname, 'src/index.ts'),
      name: 'GameBackendSDK',
      formats: ['es'],
      fileName: () => 'game-backend-sdk.js',
    },
    rollupOptions: {
      output: {
        exports: 'named',
      },
    },
    outDir: 'dist',
    emptyOutDir: true,
    target: 'es2015',
    minify: false,
  },
})
