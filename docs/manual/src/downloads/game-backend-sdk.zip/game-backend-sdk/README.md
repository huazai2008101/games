# @game-platform/backend-sdk

游戏后端 TypeScript SDK —— 基于事件驱动，集成到平台 goja 引擎中运行。

## 安装

### 从 npm（发布后）

```bash
npm install @game-platform/backend-sdk
```

### 本地使用（未发布到 npm）

**方式 A — file 协议（推荐）**

```json
{
  "dependencies": {
    "@game-platform/backend-sdk": "file:./sdks/game-backend-sdk"
  }
}
```

`npm install` 后即可正常 `import`，获得 `platform` 的类型提示。

**方式 B — 直接复制类型文件**

本项目不需要运行时导入 SDK（运行时由 goja 注入 `platform` 全局对象），只需要类型声明。将 `dist/index.d.ts` 复制到项目中，在 `tsconfig.json` 添加：

```json
{
  "compilerOptions": {
    "types": ["./types/game-backend-sdk.d.ts"]
  }
}
```

这样写游戏逻辑时 `platform.xxx` 就有智能提示，但编译产物不包含 SDK 代码（goja 会提供）。

**方式 C — npm link**

```bash
cd game-backend-sdk && npm link
cd my-game-project && npm link @game-platform/backend-sdk
```

## 快速开始

```typescript
import { GameLifecycle, registerGame } from '@game-platform/backend-sdk'

// 1. 继承 GameLifecycle，重写游戏逻辑
class PokerGame extends GameLifecycle {

  onInit() {
    // 初始化牌桌。getPlayers() 返回 [{id, name}] 名册快照
    const players = platform.getPlayers()
    players.forEach(p => {
      platform.setGameState('score_' + p.id, 0)
    })
    platform.broadcast('game:initialized', { players })
  }

  // 玩家进入或重连，可选实现：落座、夺回被托管的座位
  onPlayerJoin(playerId: string, displayName: string) {}

  // 玩家最后一条连接断开，可选实现：座位转托管
  onPlayerLeave(playerId: string) {}

  // 状态对账（必须实现）：首次入场、断线重连、页面恢复可见都会触发
  onSync(playerId: string) {
    platform.sendTo(playerId, 'game:sync', {
      scores: platform.getPlayers().map(p => ({
        player_id: p.id,
        score: platform.getGameState('score_' + p.id) || 0,
      })),
    })
  }

  onAction(playerId: string, action: string, payload: any) {
    switch (action) {
      case 'bet': {
        const betRoundId = platform.beginRound()
        if (!betRoundId) return
        let committed = false
        try {
          if (!platform.deductBalance(playerId, payload.amount, 'bet')) return
        } finally {
          committed = platform.endRound()
        }
        if (!committed) return
        platform.broadcast('game:player_bet', { player_id: playerId, amount: payload.amount, roundId: betRoundId })
        break
      }

      case 'fold':
        platform.broadcast('game:player_fold', { player_id: playerId })
        break

      case 'win': {
        const winRoundId = platform.beginRound()
        if (!winRoundId) return
        const currentScore = platform.getGameState('score_' + playerId) || 0
        const nextScore = currentScore + payload.balance
        let committed = false
        try {
          if (!platform.rewardBalance(playerId, payload.balance, 'payout')) return
          platform.recordResult(playerId, 'win', payload.balance)
        } finally {
          committed = platform.endRound()
        }
        if (!committed) return
        platform.setGameState('score_' + playerId, nextScore)
        platform.broadcast('game:score_updated', { player_id: playerId, score: nextScore, roundId: winRoundId })
        break
      }
    }
  }

  onFinish() {
    // 结算排名
    const players = platform.getPlayers()
    const results: Record<string, number> = {}
    players.forEach(p => {
      results[p.id] = platform.getGameState('score_' + p.id) || 0
    })
    platform.broadcast('game:finished', { results })
  }
}

// 2. 注册游戏（引擎按全局名调用 onInit / onAction / onSync / onFinish 等钩子）
registerGame(new PokerGame())
```

## 生命周期钩子

| 钩子 | 触发时机 |
|------|---------|
| `onInit()` | 引擎就绪（会话 ready 之后），广播初始状态 |
| `onAction(playerId, action, payload)` | 玩家执行玩法动作（仅 Playing 态） |
| `onSync(playerId)` | 玩家经平台 `state:sync` 拉取权威快照：首次入场、断线重连、页面恢复可见、错误后对账；任何存活状态均可，用 `platform.sendTo(playerId, ...)` 应答本人全量状态 |
| `onPlayerJoin(playerId, displayName)` | 可选。玩家进入或重连 |
| `onPlayerLeave(playerId)` | 可选。玩家最后一条连接断开，成员资格保留 |
| `onFinish()` | 会话结束，结算收尾 |

另有一个可选的全局 `onStart()`：会话进入 playing 时若在模块顶层定义则被调用，适合满员即开局的玩法触发第一手动作（不经 `registerGame` 注册）。

## 构建并提交到平台

逻辑包必须是单文件 IIFE bundle。推荐用 vite lib 模式构建（SDK 源码包内含参考配置）：

```ts
// vite.config.ts
import { defineConfig } from 'vite'

export default defineConfig({
  build: {
    target: 'es2015',
    lib: { entry: 'src/game.ts', name: 'Game', formats: ['iife'], fileName: () => 'game.js' },
  },
})
```

```bash
npm install && npm run build
# 产物 dist/game.js 全文作为提审单的 backendJsBundle 字符串提交
```

## platform 全局 API

SDK 提供了完整的 `platform` 类型声明，游戏代码中可以直接调用：

```typescript
// 通信
platform.broadcast(event, data)     // 发送事件给会话内所有成员（含观战者）
platform.sendTo(playerId, event, data)  // 发给指定玩家，非成员静默忽略
platform.getPlayers()               // 玩家名册快照 [{id, name}]
platform.isPlayerOnline(playerId)   // 玩家当前是否有存活连接
platform.finishSession()            // 结束整个会话并释放房间
platform.reopenSession()            // 会话退回等待态，允许新玩家加入（room 模式续局）

// 状态（会话内存级，不持久化）
platform.getGameState(key)          // 读取游戏状态
platform.setGameState(key, value)   // 写入游戏状态

// 随机
platform.random()                   // 密码学安全随机数 [0, 1)
platform.beginFairRound(seedId)     // 公平随机：生成保密种子并广播 SHA-256 承诺
platform.getFairRandom(seedId, index) // 从公平种子派生第 index 个随机数
platform.revealFairRound(seedId)    // 揭示种子，玩家可复算随机过程

// 日志与定时器（会话结束统一清理）
platform.log(...args)               // 服务端日志
platform.setTimeout(fn, ms)         // 延时回调
platform.setInterval(fn, ms)        // 定时回调
platform.clearTimer(id)             // 取消定时器

// 钱包（回合内）
platform.beginRound()               // 显式开始业务回合，返回平台生成的 roundId；已有未闭合回合时返回空串
platform.endRound()                 // 显式结束当前业务回合，不接受参数
platform.getRoundId()               // 当前回合 ID，没有回合时为空字符串
platform.lastRoundError()           // endRound 返回 false 后读取钱包拒绝原因（如 insufficient balance）
platform.deductBalance(playerId, amount, desc?)   // 扣金币，必须处于 beginRound/endRound 之间
platform.rewardBalance(playerId, amount, desc?)   // 奖金币，必须处于 beginRound/endRound 之间
platform.recordResult(playerId, 'win'|'lose'|'draw', scoreDelta?, meta?)  // 登记对局记录
platform.getBalance(playerId)       // 玩家当前（引擎缓存的）余额，禁止用于扣款前预检
platform.getBalanceVersion(playerId) // 最近一次已提交余额的单调版本号（未知为 0）；结果载荷应携带，客户端据此丢弃乱序的余额推送
```

所有会产生钱包流水的游戏流程都必须显式调用 `beginRound` / `endRound`。
平台不会隐式创建回合；没有 active round 时，`deductBalance` 和
`rewardBalance` 返回 `false`，不会写入 `player_transaction`。如果回调返回时
仍有未关闭的 round，平台会清理该 round 并将本次回调视为脚本错误。
`roundId` 只能由平台在服务端生成，`beginRound` / `endRound` 都不接受客户端或动作 payload 传入的 roundId。

## 打包产物

```
dist/
├── game-backend-sdk.js   ← ES bundle（goja 直接加载）
└── *.d.ts                ← TypeScript 类型声明
```
