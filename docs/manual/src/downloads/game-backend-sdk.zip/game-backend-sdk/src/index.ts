// Game Backend SDK — Engine entry point

import type { PlatformAPI } from './api';
import { EventEmitter } from './events';
import { GameLifecycle } from './lifecycle';

export type { PlatformAPI };
export { EventEmitter, GameLifecycle };

// Access the goja-injected platform global.
declare const platform: PlatformAPI;

/**
 * Register a game instance. The engine will call lifecycle methods automatically.
 */
export function registerGame(game: GameLifecycle): void {
  (globalThis as any).onInit = function () { game.onInit(); };
  (globalThis as any).onAction = function (playerId: string, action: string, payload: any) {
    game.onAction(playerId, action, payload);
  };
  (globalThis as any).onSync = function (playerId: string) {
    game.onSync(playerId);
  };
  (globalThis as any).onFinish = function () { game.onFinish(); };
  (globalThis as any).onPlayerLeave = function (playerId: string) {
    if (game.onPlayerLeave) game.onPlayerLeave(playerId);
  };
  (globalThis as any).onPlayerJoin = function (playerId: string, displayName: string) {
    if (game.onPlayerJoin) game.onPlayerJoin(playerId, displayName);
  };
  platform.log('Game registered successfully');
}
