// Game Backend SDK — Event emitter for game logic

interface EventHandler {
  (...args: any[]): void;
}

export class EventEmitter {
  private handlers: Record<string, EventHandler[]> = {};

  on(event: string, handler: EventHandler): this {
    if (!this.handlers[event]) {
      this.handlers[event] = [];
    }
    this.handlers[event].push(handler);
    return this;
  }

  off(event: string, handler?: EventHandler): this {
    if (!handler) {
      delete this.handlers[event];
      return this;
    }
    var handlers = this.handlers[event];
    if (handlers) {
      this.handlers[event] = handlers.filter(function (h) { return h !== handler; });
    }
    return this;
  }

  emit(event: string, ...args: any[]): void {
    var handlers = this.handlers[event];
    if (handlers) {
      for (var i = 0; i < handlers.length; i++) {
        try {
          handlers[i].apply(null, args);
        } catch (e) {
          platform.log('EventEmitter error in "' + event + '": ' + (e as any)?.message);
        }
      }
    }
  }
}
