import type { HostGameConfig } from './types';

const configRequestType = 'onlinegame:config:request';
const configResponseType = 'onlinegame:config:response';
const ticketRequestType = 'onlinegame:ticket:request';
const ticketResponseType = 'onlinegame:ticket:response';
const gameExitType = 'onlinegame:game:exit';

export interface HostConfigOptions {
  timeoutMs?: number;
  /**
   * The expected parent origin. If omitted, it is inferred from document.referrer.
   * When no specific origin can be determined the request FAILS CLOSED rather
   * than broadcasting to '*' — a game must know its host origin so that a
   * malicious embedder cannot receive the host's messages (or a WS ticket).
   */
  targetOrigin?: string;
}

/**
 * Requests the game configuration from the lobby host (the embedding parent).
 * The response carries everything the game needs EXCEPT a credential: WS
 * tickets are minted on demand via the returned `requestTicket` so the player's
 * access token never enters the game iframe.
 */
export function requestHostGameConfig(options: HostConfigOptions = {}): Promise<HostGameConfig> {
  const timeoutMs = options.timeoutMs ?? 5000;
  const targetOrigin = options.targetOrigin ?? inferParentOrigin();
  if (!targetOrigin) {
    return Promise.reject(new Error('game host origin could not be determined; refusing to broadcast to "*"'));
  }

  return new Promise((resolve, reject) => {
    if (window.parent === window) {
      reject(new Error('game host is not available'));
      return;
    }

    const timer = window.setTimeout(() => {
      window.removeEventListener('message', onMessage);
      reject(new Error('game host config request timed out'));
    }, timeoutMs);

    function onMessage(event: MessageEvent) {
      if (event.source !== window.parent) return;
      if (event.origin !== targetOrigin) return;

      const data = event.data;
      if (!data || data.type !== configResponseType) return;

      const payload = data.payload as Partial<Omit<HostGameConfig, 'requestTicket'>> | undefined;
      if (!payload?.wsUrl || !payload.gameId) {
        return;
      }

      window.clearTimeout(timer);
      window.removeEventListener('message', onMessage);
      resolve({
        wsUrl: payload.wsUrl,
        gameId: String(payload.gameId),
        requestTicket: () => requestHostTicket({ targetOrigin }),
        sessionId: payload.sessionId ? String(payload.sessionId) : undefined,
        roomCode: payload.roomCode ? String(payload.roomCode) : undefined,
        spectate: Boolean(payload.spectate),
      });
    }

    window.addEventListener('message', onMessage);
    window.parent.postMessage({ type: configRequestType }, targetOrigin);
  });
}

/**
 * Requests a fresh single-use WS ticket from the lobby host. Called by the
 * client on each connect/reconnect so a long game session survives the player's
 * short-lived access token (the host re-mints).
 */
export function requestHostTicket(options: { targetOrigin: string; timeoutMs?: number } ): Promise<string | null> {
  const targetOrigin = options.targetOrigin;
  const timeoutMs = options.timeoutMs ?? 5000;
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      window.removeEventListener('message', onMessage);
      reject(new Error('game host ticket request timed out'));
    }, timeoutMs);

    function onMessage(event: MessageEvent) {
      if (event.source !== window.parent) return;
      if (event.origin !== targetOrigin) return;
      const data = event.data;
      if (!data || data.type !== ticketResponseType) return;
      window.clearTimeout(timer);
      window.removeEventListener('message', onMessage);
      resolve((data.payload && data.payload.ticket) || null);
    }

    window.addEventListener('message', onMessage);
    window.parent.postMessage({ type: ticketRequestType }, targetOrigin);
  });
}

export function hostConfigMessageTypes() {
  return {
    configRequest: configRequestType,
    configResponse: configResponseType,
    ticketRequest: ticketRequestType,
    ticketResponse: ticketResponseType,
    gameExit: gameExitType,
  } as const;
}

/**
 * Notifies the lobby host that the player invoked the game's OWN exit/back
 * control, so the host can navigate back (route change, history back, ... —
 * the host decides). Fire-and-forget with the same origin discipline as the
 * config handshake: the message only goes to the inferred parent origin, and
 * standalone previews (no embedding parent) return false instead of posting.
 */
export function notifyGameExit(options: { targetOrigin?: string } = {}): boolean {
  const targetOrigin = options.targetOrigin ?? inferParentOrigin();
  if (!targetOrigin || window.parent === window) return false;
  window.parent.postMessage({ type: gameExitType }, targetOrigin);
  return true;
}

function inferParentOrigin(): string | null {
  if (!document.referrer) return null;
  try {
    return new URL(document.referrer).origin;
  } catch {
    return null;
  }
}
