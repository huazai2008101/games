// Game Frontend SDK — WebSocket Client

import { GameLifecycle } from './lifecycle';
import type { GameClientOptions, GameMessage } from './types';

let seqCounter = 0;

export class GameClient {
  private ws: WebSocket | null = null;
  private options: GameClientOptions;
  private lifecycle: GameLifecycle | null = null;
  private reconnectAttempts = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private connected = false;
  private intentionalClose = false;

  constructor(options: GameClientOptions) {
    this.options = {
      autoReconnect: true,
      reconnectDelay: 3000,
      maxReconnectAttempts: 5,
      ...options,
    };
  }

  /**
   * Register lifecycle hooks.
   */
  use(lifecycle: GameLifecycle): this {
    this.lifecycle = lifecycle;
    return this;
  }

  /**
   * Connect to the game server. Asks the ticket provider for a single-use WS
   * ticket (the lobby host mints it on demand), then opens the socket with
   * ?ticket= so the player's access token never enters the iframe, the WS URL,
   * proxy logs, browser history, or Referer.
   *
   * Returns a promise so callers can await the handshake kickoff; it does not
   * wait for the socket to open. Each connect/reconnect requests a FRESH ticket,
   * so a long session survives access-token expiry (the host re-mints).
   */
  async connect(): Promise<void> {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    this.intentionalClose = false;

    const ticket = await this.options.ticketProvider();
    if (!ticket) {
      if (!this.intentionalClose) {
        this.tryReconnect();
      }
      return;
    }

    const params = new URLSearchParams({
      ticket,
      gameId: String(this.options.gameId),
    });
    if (this.options.sessionId) {
      params.set('sessionId', this.options.sessionId);
    }
    if (this.options.roomCode) {
      params.set('roomCode', this.options.roomCode);
    }
    if (this.options.spectate) {
      params.set('spectate', '1');
    }

    const url = `${this.options.url}?${params.toString()}`;
    this.ws = new WebSocket(url);

    this.ws.onopen = () => {
      this.connected = true;
      this.reconnectAttempts = 0;
      this.lifecycle?.onConnect?.();
    };

    this.ws.onmessage = (event) => {
      try {
        const msg: GameMessage = JSON.parse(event.data as string);
        this.dispatch(msg);
      } catch (e) {
        console.error('[GameSDK] Failed to parse message:', e);
      }
    };

    this.ws.onclose = () => {
      this.connected = false;
      this.lifecycle?.onDisconnect?.();
      if (this.intentionalClose) return;
      this.tryReconnect();
    };

    this.ws.onerror = (err) => {
      console.error('[GameSDK] WebSocket error:', err);
    };
  }

  /**
   * Send a game action to the server.
   */
  sendAction(action: string, payload: any): void {
    // Spectators are read-only: never send actions (the server rejects them
    // too, but blocking here avoids balanceless round-trips and error toasts).
    if (this.options.spectate) {
      console.warn('[GameSDK] spectators cannot send actions');
      return;
    }
    this.send({
      type: 'action',
      action,
      payload,
      timestamp: Date.now(),
      seq: ++seqCounter,
    });
  }

  /**
   * Send a system/lifecycle message to the server.
   */
  private sendSystem(action: string, payload: any): void {
    // Spectators cannot drive session lifecycle (ready/start/finish).
    if (this.options.spectate) {
      return;
    }
    this.send({
      type: 'system',
      action,
      payload,
      timestamp: Date.now(),
      seq: ++seqCounter,
    });
  }

  /**
   * Notify the server that the game is ready.
   */
  ready(): void {
    this.sendSystem('session:ready', {});
  }

  /**
   * Pull this player's authoritative state snapshot. The platform routes the
   * request to the engine's onSync hook — valid in any live session state, so
   * reconnects and first entry recover without retry dances. Spectator
   * connections don't carry wallet state and are rejected server-side.
   */
  sync(): void {
    this.sendSystem('state:sync', {});
  }

  /**
   * Notify the server to start the game.
   */
  start(): void {
    this.sendSystem('session:start', {});
  }

  /**
   * Notify the server to finish the game.
   */
  finish(): void {
    this.sendSystem('session:finish', {});
  }

  /**
   * Disconnect from the server.
   */
  disconnect(): void {
    this.intentionalClose = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  /**
   * Check if connected.
   */
  isConnected(): boolean {
    return this.connected;
  }

  // --- Private ---

  private send(msg: Omit<GameMessage, 'playerId' | 'gameId' | 'sessionId'>): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    }
  }

  private dispatch(msg: GameMessage): void {
    const lc = this.lifecycle;
    if (!lc) return;

    switch (msg.type) {
      case 'system':
        this.dispatchSystem(msg, lc);
        break;
      case 'event':
        lc.onEvent?.(msg.action, msg.payload);
        break;
      case 'action':
        lc.onPlayerAction?.(msg.playerId ?? '', msg.action, msg.payload);
        break;
    }
  }

  private dispatchSystem(msg: GameMessage, lc: GameLifecycle): void {
    switch (msg.action) {
      case 'session:joined':
        lc.onSessionJoin?.(msg.payload?.sessionId, msg.payload?.playerCount);
        break;
      case 'session:spectating':
        lc.onSpectate?.(msg.payload?.sessionId, msg.payload?.playerCount);
        break;
      case 'session:state':
        lc.onStateChange?.(msg.payload?.state);
        if (msg.payload?.state === 'ready') {
          lc.onReady?.();
        }
        break;
      case 'session:started':
        lc.onStart?.(msg.payload);
        break;
      case 'session:finished':
      case 'game:finished':
        lc.onFinish?.(msg.payload);
        break;
      case 'error':
        lc.onError?.(msg.payload?.message ?? 'Unknown error');
        break;
      default:
        // Platform-level system messages (e.g. wallet:error with the exact
        // wallet failure) must reach the game — without this fallback they were
        // silently dropped and players saw a generic result instead of the real
        // cause (e.g. insufficient balance after an admin adjustment).
        lc.onEvent?.(msg.action, msg.payload);
        break;
    }
  }

  private tryReconnect(): void {
    if (!this.options.autoReconnect) return;
    if (this.reconnectAttempts >= (this.options.maxReconnectAttempts ?? 5)) {
      console.warn('[GameSDK] Max reconnect attempts reached');
      this.lifecycle?.onReconnectFailed?.();
      return;
    }

    this.reconnectAttempts++;
    const delay = this.options.reconnectDelay ?? 3000;
    console.log(`[GameSDK] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);

    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }
}
