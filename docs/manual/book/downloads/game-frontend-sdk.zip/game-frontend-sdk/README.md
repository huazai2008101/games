# @game-platform/frontend-sdk

游戏前端 TypeScript SDK —— 基于 WebSocket + 事件驱动，封装完整游戏生命周期。

## 安装

### 从 npm（发布后）

```bash
npm install @game-platform/frontend-sdk
```

### 本地使用（未发布到 npm）

**方式 A — file 协议（推荐）**

将 SDK 文件夹放到项目中，在 `package.json` 添加：

```json
{
  "dependencies": {
    "@game-platform/frontend-sdk": "file:./sdks/game-frontend-sdk"
  }
}
```

然后 `npm install`，即可正常 `import`。

**方式 B — 直接引用构建产物**

将 `dist/game-frontend-sdk.es.js` 和 `dist/index.d.ts` 复制到 `src/` 下：

```
src/
├── game.ts
├── game-frontend-sdk.es.js    ← 可执行代码
└── game-frontend-sdk.d.ts     ← 类型声明（index.d.ts 改名）
```

```typescript
import { GameClient, GameLifecycle } from './game-frontend-sdk.es.js'
```

**方式 C — npm link（开发调试）**

```bash
cd game-frontend-sdk && npm link
cd my-game-project && npm link @game-platform/frontend-sdk
```

## 快速开始

```typescript
import { GameClient, GameLifecycle, requestHostGameConfig } from '@game-platform/frontend-sdk'

// 1. 继承 GameLifecycle，重写生命周期方法
class MyGame extends GameLifecycle {

  // WebSocket 连接成功
  onConnect() {
    console.log('已连接到游戏服务器')
  }

  // 收到服务端事件
  onEvent(action: string, payload: any) {
    switch (action) {
      case 'session:started':
        this.renderGame()
        break
      case 'game:player_moved':
        this.updatePlayerPosition(payload.player_id, payload.move)
        break
      case 'game:score_updated':
        this.updateScore(payload.player_id, payload.score)
        break
    }
  }

  // 收到其他玩家的操作
  onPlayerAction(playerId: string, action: string, payload: any) {
    console.log(`玩家 ${playerId} 执行了 ${action}`)
  }

  // 游戏结束
  onFinish(data: any) {
    this.showResult(data.results)
  }

  // 出错
  onError(error: string) {
    alert('游戏出错: ' + error)
  }
}

// 2. 从平台宿主页面获取连接配置，创建客户端，注册生命周期，连接
const config = await requestHostGameConfig()
const client = new GameClient({
  url: config.wsUrl,
  gameId: config.gameId,
  // 票据按需索取：游戏前端不持有玩家 token，SDK 每次连接与重连
  // 都通过 ticketProvider 向宿主换取一次性票据（单次有效，30 秒过期）
  ticketProvider: config.requestTicket,
  sessionId: config.sessionId,
  roomCode: config.roomCode,
  spectate: config.spectate,
})

client.use(new MyGame())
client.connect()

// 3. 发送玩家操作
client.sendAction('move', { x: 10, y: 20 })
client.sendAction('score', { balance: 15 })
```

## 完整生命周期钩子

| 钩子 | 触发时机 |
|------|---------|
| `onConnect()` | WebSocket 连接建立 |
| `onSessionJoin(sessionId, playerCount)` | 成功加入游戏会话 |
| `onSpectate(sessionId)` | 以观战身份加入会话 |
| `onReady()` | 游戏准备就绪（可开始） |
| `onStart(data)` | 游戏开始 |
| `onEvent(action, payload)` | 收到服务端事件 |
| `onPlayerAction(playerId, action, payload)` | 其他玩家的操作 |
| `onFinish(data)` | 游戏结束 |
| `onError(error)` | 发生错误 |
| `onDisconnect()` | 连接断开 |
| `onReconnectFailed()` | 自动重连耗尽（默认间隔 3 秒、最多 5 次） |
| `onStateChange(state)` | 会话状态变化 |

## 平台系统消息

除游戏自定义事件外，平台会通过 WebSocket 下发若干系统级消息。未知系统消息
统一转发到 `onEvent(action, payload)`，游戏按需处理：

| 消息 | 载荷 | 说明 |
|------|------|------|
| `session:started` | `{sessionId, playerCount}` | 会话进入 Playing（前端 `onStart` 钩子由此触发），游戏玩法动作开始受理 |
| `state:sync` 应答 | 游戏自定义 | `client.sync()` 发起的只读快照拉取，平台路由到引擎 `onSync(playerId)`；任何存活状态均可，适合首次入场、断线重连、页面恢复可见时对账 |
| `wallet:balance` | `{balance, version, source}` | 钱包余额实时推送：本玩家余额在任何路径提交变更（管理端调账、其他窗口/会话的回合结算等）后下发。`version` 为单调递增计数，只应用比本地新的推送可防乱序回退。若游戏在结果载荷中携带 `platform.getBalanceVersion()` 的版本号，客户端应在应用结果时同步抬高该水位，使早于结果的延迟推送被正确丢弃 |
| `wallet:error` | `{requestId, roundId, error}` | 钱包拒绝（如余额不足），携带具体原因 |

推荐实践：收到 `wallet:balance` 时更新余额显示；`document.visibilitychange`
恢复可见时主动 `client.sync()` 向引擎拉取权威快照对账，覆盖挂机期间漏推的
极端情况（替代任何轮询）。

## 平台宿主配置

`requestHostGameConfig()` 会向父级平台页面请求连接配置。平台返回 `wsUrl`、
`gameId` 与 `requestTicket()`（一次性票据索取函数，游戏前端不持有玩家 token），
房间模式或观战入口可额外返回：

| 字段 | 说明 |
|------|------|
| `sessionId` | 直接加入指定会话 |
| `roomCode` | 通过房间码加入房间模式会话 |
| `spectate` | 以只读观战身份加入 |

宿主协议基于 postMessage 完成，SDK 自动处理 origin 校验；推断不出可信
origin 时 fail-closed，不会将配置广播到未知来源。

## GameClient API

```typescript
client.sendAction(action: string, payload: any)  // 发送玩家操作
client.ready()    // 通知服务端准备就绪
client.start()    // 通知服务端开始游戏
client.finish()   // 通知服务端结束游戏
client.sync()     // 拉取本人权威状态快照（平台路由到引擎 onSync）
client.disconnect()  // 断开连接
client.isConnected() // 是否已连接
```

## 打包产物

```
dist/
├── game-frontend-sdk.es.js   ← ESM 格式（import 使用）
├── game-frontend-sdk.umd.js  ← UMD 格式（<script> 标签 / require 使用）
└── *.d.ts                    ← TypeScript 类型声明
```
